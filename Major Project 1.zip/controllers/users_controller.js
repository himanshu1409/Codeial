module.exports.profile = function (req, res) {
  res.send("<h1>User Profile</h1>");
};
